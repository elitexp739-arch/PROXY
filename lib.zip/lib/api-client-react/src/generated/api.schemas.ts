export interface HealthStatus {
  status: string;
}

export interface LoginToken {
  token: string;
}

export interface Key {
  id: number;
  key: string;
  type: string;
  duration_days: number;
  is_active: boolean;
  expires_at: string;
  locked_ip: string | null;
  created_by: number | null;
  reset_count: number;
  last_reset_at: string | null;
}

export interface KeyInput {
  type: string;
  duration_days: number;
}

export interface Seller {
  user_id: number;
  username: string | null;
  balance: number;
  added_at: string;
}

export interface SellerInput {
  user_id: number;
  username: string | null;
}

export interface BalanceInput {
  amount: number;
}

export interface Price {
  type: string;
  duration_days: number;
  price: number;
}

export interface PriceInput {
  type: string;
  duration_days: number;
  price: number;
}

export interface Stats {
  totalKeys: number;
  activeKeys: number;
  lockedKeys: number;
  expiredKeys: number;
  sellersCount: number;
}

export interface BotStatus {
  online: boolean;
  botUsername: string | null;
  enabled: boolean;
}
