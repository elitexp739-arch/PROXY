import { useQuery, useMutation } from "@tanstack/react-query";
import type {
  QueryFunction,
  QueryKey,
  UseQueryOptions,
  UseQueryResult,
  UseMutationOptions,
  UseMutationResult,
} from "@tanstack/react-query";

import type {
  HealthStatus,
  LoginToken,
  Key,
  KeyInput,
  Seller,
  SellerInput,
  BalanceInput,
  Price,
  PriceInput,
  Stats,
  BotStatus,
} from "./api.schemas";

import { customFetch } from "../custom-fetch";
import type { ErrorType } from "../custom-fetch";

// ─── Health ────────────────────────────────────────────────────────────────

export const getHealthCheckQueryKey = () => [`/api/healthz`] as const;

export const healthCheck = async (options?: RequestInit): Promise<HealthStatus> =>
  customFetch<HealthStatus>(`/api/healthz`, { ...options, method: "GET" });

export function useHealthCheck<TData = HealthStatus, TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<HealthStatus, TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getHealthCheckQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => healthCheck({ signal }), ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

// ─── Auth ─────────────────────────────────────────────────────────────────

export const login = async (body: { password: string }): Promise<LoginToken> =>
  customFetch<LoginToken>(`/api/auth/login`, {
    method: "POST",
    body: JSON.stringify(body),
  });

export function useLogin<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<LoginToken, TError, { data: { password: string } }>
): UseMutationResult<LoginToken, TError, { data: { password: string } }> {
  return useMutation({
    mutationFn: ({ data }) => login(data),
    ...options,
  });
}

// ─── Stats ────────────────────────────────────────────────────────────────

export const getGetStatsQueryKey = () => [`/api/stats`] as const;

export const getStats = async (options?: RequestInit): Promise<Stats> =>
  customFetch<Stats>(`/api/stats`, { ...options, method: "GET" });

export function useGetStats<TData = Stats, TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<Stats, TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getGetStatsQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => getStats({ signal }), ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

// ─── Bot Status ───────────────────────────────────────────────────────────

export const getGetBotStatusQueryKey = () => [`/api/bot/status`] as const;

export const getBotStatus = async (options?: RequestInit): Promise<BotStatus> =>
  customFetch<BotStatus>(`/api/bot/status`, { ...options, method: "GET" });

export function useGetBotStatus<TData = BotStatus, TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<BotStatus, TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getGetBotStatusQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => getBotStatus({ signal }), refetchInterval: 10000, ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

// ─── Keys ─────────────────────────────────────────────────────────────────

export const getListKeysQueryKey = () => [`/api/keys`] as const;

export const listKeys = async (options?: RequestInit): Promise<Key[]> =>
  customFetch<Key[]>(`/api/keys`, { ...options, method: "GET" });

export function useListKeys<TData = Key[], TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<Key[], TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getListKeysQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => listKeys({ signal }), ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

export const createKey = async (body: KeyInput): Promise<Key> =>
  customFetch<Key>(`/api/keys`, {
    method: "POST",
    body: JSON.stringify(body),
  });

export function useCreateKey<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<Key, TError, { data: KeyInput }>
): UseMutationResult<Key, TError, { data: KeyInput }> {
  return useMutation({
    mutationFn: ({ data }) => createKey(data),
    ...options,
  });
}

export const deleteKey = async (id: number): Promise<void> =>
  customFetch<void>(`/api/keys/${id}`, { method: "DELETE" });

export function useDeleteKey<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<void, TError, { id: number }>
): UseMutationResult<void, TError, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => deleteKey(id),
    ...options,
  });
}

export const resetKeyIp = async (id: number): Promise<Key> =>
  customFetch<Key>(`/api/keys/${id}/reset-ip`, { method: "POST" });

export function useResetKeyIp<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<Key, TError, { id: number }>
): UseMutationResult<Key, TError, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => resetKeyIp(id),
    ...options,
  });
}

// ─── Sellers ──────────────────────────────────────────────────────────────

export const getListSellersQueryKey = () => [`/api/sellers`] as const;

export const listSellers = async (options?: RequestInit): Promise<Seller[]> =>
  customFetch<Seller[]>(`/api/sellers`, { ...options, method: "GET" });

export function useListSellers<TData = Seller[], TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<Seller[], TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getListSellersQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => listSellers({ signal }), ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

export const addSeller = async (body: SellerInput): Promise<Seller> =>
  customFetch<Seller>(`/api/sellers`, {
    method: "POST",
    body: JSON.stringify(body),
  });

export function useAddSeller<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<Seller, TError, { data: SellerInput }>
): UseMutationResult<Seller, TError, { data: SellerInput }> {
  return useMutation({
    mutationFn: ({ data }) => addSeller(data),
    ...options,
  });
}

export const removeSeller = async (userId: number): Promise<void> =>
  customFetch<void>(`/api/sellers/${userId}`, { method: "DELETE" });

export function useRemoveSeller<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<void, TError, { userId: number }>
): UseMutationResult<void, TError, { userId: number }> {
  return useMutation({
    mutationFn: ({ userId }) => removeSeller(userId),
    ...options,
  });
}

export const addBalance = async (userId: number, body: BalanceInput): Promise<Seller> =>
  customFetch<Seller>(`/api/sellers/${userId}/balance`, {
    method: "POST",
    body: JSON.stringify(body),
  });

export function useAddBalance<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<Seller, TError, { userId: number; data: BalanceInput }>
): UseMutationResult<Seller, TError, { userId: number; data: BalanceInput }> {
  return useMutation({
    mutationFn: ({ userId, data }) => addBalance(userId, data),
    ...options,
  });
}

// ─── Prices ───────────────────────────────────────────────────────────────

export const getListPricesQueryKey = () => [`/api/prices`] as const;

export const listPrices = async (options?: RequestInit): Promise<Price[]> =>
  customFetch<Price[]>(`/api/prices`, { ...options, method: "GET" });

export function useListPrices<TData = Price[], TError = ErrorType<unknown>>(
  options?: { query?: UseQueryOptions<Price[], TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const queryKey = getListPricesQueryKey();
  const q = useQuery({ queryKey, queryFn: ({ signal }) => listPrices({ signal }), ...options?.query }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  q.queryKey = queryKey;
  return q;
}

export const updatePrice = async (body: PriceInput): Promise<Price> =>
  customFetch<Price>(`/api/prices`, {
    method: "PUT",
    body: JSON.stringify(body),
  });

export function useUpdatePrice<TError = ErrorType<unknown>>(
  options?: UseMutationOptions<Price, TError, { data: PriceInput }>
): UseMutationResult<Price, TError, { data: PriceInput }> {
  return useMutation({
    mutationFn: ({ data }) => updatePrice(data),
    ...options,
  });
}
